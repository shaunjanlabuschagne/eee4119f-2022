Hello! Sorry for multiple files

Please run ControllerDesign.mlx first, as the gain matrices aren't hardcoded into the simulation

Next, open up the simulation (LBSSHA005_EEE4119F_Project) and run. The box mass setting is 1 intitially.

Thank you.



